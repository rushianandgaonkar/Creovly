import type { SiteConfig, NavItem, ToolDefinition } from '../types';

export const siteConfig: SiteConfig = {
  name: 'Creovly',
  domain: 'creovly.com',
  url: 'https://creovly.com',
  tagline: 'Create smarter. Publish better.',
  description:
    'The modern workspace creators use before publishing. Optimize thumbnails, audit titles, analyze monetization, and perfect content with Creovly Publish Studio.',
  flagship: {
    name: 'Creovly Publish Studio',
    tagline: 'The unified pre-publish command center for creators',
    path: '/studio',
  },
  links: {
    twitter: 'https://twitter.com/creovly',
    github: 'https://github.com/creovly',
  },
};

export const navItems: NavItem[] = [
  { name: 'Tools', href: '/tools' },
  { name: 'Thumbnail', href: '/tools#thumbnail' },
  { name: 'Titles', href: '/tools#title' },
  { name: 'Money & Growth', href: '/tools#money-growth' },
  { name: 'Publish Studio', href: '/studio', isFlagship: true, badge: 'Flagship' },
  { name: 'Guides', href: '/guides' },
];

export const footerNavigation = {
  categories: [
    {
      title: 'Thumbnail Tools',
      items: [
        { name: 'Thumbnail Compressor', href: '/tools/youtube-thumbnail-compressor' },
        { name: 'Thumbnail Resizer', href: '/tools/youtube-thumbnail-resizer' },
        { name: 'Shorts Safe Zone', href: '/tools/youtube-shorts-safe-zone' },
      ],
    },
    {
      title: 'Title Tools',
      items: [
        { name: 'Title Checker & Analyzer', href: '/tools/youtube-title-checker' },
        { name: 'Pre-Publish Checklist', href: '/checklist' },
      ],
    },
    {
      title: 'Money & Growth',
      items: [
        { name: 'Revenue Calculator', href: '/tools/youtube-revenue-calculator' },
        { name: 'RPM Calculator', href: '/tools/youtube-rpm-calculator' },
        { name: 'Watch Hours Calculator', href: '/tools/youtube-watch-hours-calculator' },
        { name: 'Monetization Calculator', href: '/tools/youtube-monetization-calculator' },
      ],
    },
    {
      title: 'Publishing Tools',
      items: [
        { name: 'Publish Studio', href: '/studio' },
        { name: 'Pre-Publish Checklist', href: '/checklist' },
        { name: 'Creator Guides', href: '/guides' },
      ],
    },
  ],
  company: [
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
    { name: 'Privacy Policy', href: '/privacy' },
    { name: 'Terms of Service', href: '/terms' },
    { name: 'Disclaimer', href: '/disclaimer' },
  ],
};

export const plannedTools: ToolDefinition[] = [
  {
    id: 'youtube-thumbnail-compressor',
    title: 'YouTube Thumbnail Compressor',
    slug: 'youtube-thumbnail-compressor',
    href: '/tools/youtube-thumbnail-compressor',
    category: 'thumbnail',
    categoryLabel: 'Thumbnail Tools',
    description:
      'Losslessly compress thumbnails under YouTube’s 2MB file limit directly inside your browser.',
    badge: 'Popular',
    status: 'planned',
    seoTarget: 'YouTube Thumbnail Compressor',
  },
  {
    id: 'youtube-thumbnail-resizer',
    title: 'YouTube Thumbnail Resizer',
    slug: 'youtube-thumbnail-resizer',
    href: '/tools/youtube-thumbnail-resizer',
    category: 'thumbnail',
    categoryLabel: 'Thumbnail Tools',
    description:
      'Resize images to the exact 1280×720 (16:9) YouTube recommended canvas with zero quality distortion.',
    badge: 'Free',
    status: 'planned',
    seoTarget: 'YouTube Thumbnail Resizer',
  },
  {
    id: 'youtube-shorts-safe-zone',
    title: 'YouTube Shorts Safe Zone Checker',
    slug: 'youtube-shorts-safe-zone',
    href: '/tools/youtube-shorts-safe-zone',
    category: 'thumbnail',
    categoryLabel: 'Thumbnail Tools',
    description:
      'Verify that key graphics, subtitles, and logos avoid Shorts UI overlays on mobile screens.',
    badge: 'New',
    status: 'planned',
    seoTarget: 'YouTube Shorts Safe Zone',
  },
  {
    id: 'youtube-title-checker',
    title: 'YouTube Title Checker & Analyzer',
    slug: 'youtube-title-checker',
    href: '/tools/youtube-title-checker',
    category: 'title',
    categoryLabel: 'Title Tools',
    description:
      'Evaluate title length, mobile truncation cutoff points, emotional sentiment, and CTR potential.',
    badge: 'Popular',
    status: 'planned',
    seoTarget: 'YouTube Title Checker',
  },
  {
    id: 'youtube-revenue-calculator',
    title: 'YouTube Revenue Calculator',
    slug: 'youtube-revenue-calculator',
    href: '/tools/youtube-revenue-calculator',
    category: 'money-growth',
    categoryLabel: 'Money & Growth',
    description:
      'Estimate monthly and annual AdSense earnings based on views, niche CPM, and geographic audience.',
    badge: 'Popular',
    status: 'planned',
    seoTarget: 'YouTube Revenue Calculator',
  },
  {
    id: 'youtube-rpm-calculator',
    title: 'YouTube RPM Calculator',
    slug: 'youtube-rpm-calculator',
    href: '/tools/youtube-rpm-calculator',
    category: 'money-growth',
    categoryLabel: 'Money & Growth',
    description:
      'Calculate actual revenue per 1,000 views factoring YouTube’s creator revenue share and ad fill rates.',
    badge: 'Free',
    status: 'planned',
    seoTarget: 'YouTube RPM Calculator',
  },
  {
    id: 'youtube-watch-hours-calculator',
    title: 'YouTube Watch Hours Calculator',
    slug: 'youtube-watch-hours-calculator',
    href: '/tools/youtube-watch-hours-calculator',
    category: 'money-growth',
    categoryLabel: 'Money & Growth',
    description:
      'Track your progress toward the 4,000 watch hour milestone required for YouTube Partner Program (YPP).',
    badge: 'Free',
    status: 'planned',
    seoTarget: 'YouTube Watch Hours Calculator',
  },
  {
    id: 'youtube-monetization-calculator',
    title: 'YouTube Monetization Calculator',
    slug: 'youtube-monetization-calculator',
    href: '/tools/youtube-monetization-calculator',
    category: 'money-growth',
    categoryLabel: 'Money & Growth',
    description:
      'Forecast multifaceted earnings across AdSense, sponsorships, affiliate deals, and digital memberships.',
    badge: 'New',
    status: 'planned',
    seoTarget: 'YouTube Monetization Calculator',
  },
];
